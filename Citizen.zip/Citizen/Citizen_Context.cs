﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Citizen
{
    public class Citizen_Context
    {
        public Citizen_Context()
        {
            try
            {
                ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["CitizenConnection"].ConnectionString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        string ConnectionString;

        public DataTable GetCitizensData()
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection con = new SqlConnection(ConnectionString))
                {
                    SqlCommand cmd = new SqlCommand("GetCitizens_SP", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;

        }
    }
}