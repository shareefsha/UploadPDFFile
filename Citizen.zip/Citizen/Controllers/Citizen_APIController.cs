﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Citizen.Controllers
{
    public class Citizen_APIController : ApiController
    {
        Citizen_Context ctx = new Citizen_Context();
        public string GetCitizens()
        {
            string JSONString = string.Empty;
            JSONString = Newtonsoft.Json.JsonConvert.SerializeObject(ctx.GetCitizensData());
            return JSONString;
        }
    }
}
